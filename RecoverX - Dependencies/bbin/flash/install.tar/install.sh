#!/data/local/tmp/sh
# RecoverX Installation Script

mount -o remount rw /system

cat /data/local/tmp/flash_image > /system/bin/flash_image
chmod 755 /system/bin/flash_image

/system/bin/flash_image recovery /data/local/tmp/recoverx.img

mount -o remount ro /system